﻿function hide1() {
    let frm1 = document.getElementById("frm1");

    if (frm1.style.display === "none") {
        frm1.style.display = "block";
        frm2.style.display = "none";
        frm3.style.display = "none";
    } else {
        frm1.style.display = "none";
    }

}

function hide2() {
    let frm2 = document.getElementById("frm2");

    if (frm2.style.display === "none") {
        frm2.style.display = "block";
        frm1.style.display = "none";
        frm3.style.display = "none";
    } else {
        frm2.style.display = "none";

    }

}
function hide3() {
    let frm3 = document.getElementById("frm3");
    let frm1 = document.getElementById("frm1");
    let frm2 = document.getElementById("frm2");

    if (frm3.style.display === "none") {
        frm3.style.display = "block";
        frm1.style.display = "none";
        frm2.style.display = "none";
    } else {
        frm3.style.display = "none";
    }
}


function check() {
    var input = document.getElementById('nrzam');
    var pattern = /^\d{1,2}\/\d{1,2}\/\d{4}\/ZS$/;
    if (pattern.test(input.value)) {
        console.log('Dane są poprawne');
    } else {
        alert('Dane są niepoprawne');
        return;
    }
};
