﻿using Microsoft.AspNetCore.Mvc;
using mvc1.Models;
using System.Diagnostics;
using Dapper;
using MySql.Data.MySqlClient;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace mvc1.Controllers
{
    public class HomeController : Controller
    {

        private readonly string connectionString = "Server=10.20.6.83;Port=3306;Database=moja_baza_ubuntu;Uid=frodo1;Pwd=zaq1@WSX;";


        public IActionResult Index()
        {
            using var connection = new MySqlConnection(connectionString);
            var orders = connection.Query<Order>(
                "SELECT ID, Nr_zamowienia, ID_klienta, Data_zamowienia, Ilosc FROM Orders;"
            ).ToList();

            ViewBag.orders = orders; 

            var customers = connection.Query<Customer>(
                "SELECT ID_klienta, nazwa_klienta, Kraj, miejscowosc FROM Customers WHERE nazwa_klienta IS NOT NULL;"
            ).ToList();
            ViewBag.customers = customers;


            var products = connection.Query<Product>(
                "SELECT ID_produktu,nazwa_produktu,cena_produktu,ID_zamowienia FROM Products;"
            ).ToList();
            ViewBag.products = products;

            return View();
        }
        [HttpPost]
        public IActionResult WypiszKlientow()
        {
            using var connection = new MySqlConnection(connectionString);

            var customers = connection.Query<Customer>(
                "SELECT ID_klienta, nazwa_klienta, Kraj, miejscowosc FROM Customers;"
            ).ToList();

            return View(customers);
        }
        [HttpPost]

        public IActionResult DodajZamowienie(Order zamowienie)
        {
            if (ModelState.IsValid)
            {
                using var connection = new MySqlConnection(connectionString);

                string query = "INSERT INTO Orders (Nr_zamowienia, ID_klienta, Data_zamowienia, Ilosc) VALUES (@NrZamowienia, @IDKlienta, @DataZamowienia, @Ilosc)";

                connection.Execute(query, new { NrZamowienia = zamowienie.Nr_zamowienia, IDKlienta = zamowienie.ID_klienta, DataZamowienia = zamowienie.Data_zamowienia, Ilosc = zamowienie.Ilosc });

                return RedirectToAction("Index");
            }

            return View("DodajZamowienie", zamowienie);
        }


        public IActionResult WypiszZamowienia()
        {
            using var connection = new MySqlConnection(connectionString);

            var orders = connection.Query<Order>(
                "SELECT ID, Nr_zamowienia,ID_klienta,Data_zamowienia,Ilosc FROM Orders;"
            ).ToList();
     

            return View(orders);
        }
        [HttpPost]





        public IActionResult WypiszProdukty()
        {
            using var connection = new MySqlConnection(connectionString);

            var products = connection.Query<Product>(
                "SELECT ID_produktu,nazwa_produktu,cena_produktu,ID_zamowienia FROM Products;"
            ).ToList();

            return View(products);
        }
        [HttpPost]
        public IActionResult DodajKlienta(Customer1 customer)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                string insertQuery = "INSERT INTO Customers (nazwa_klienta, Kraj, miejscowosc) VALUES (@Nazwa_Klienta, @Kraj, @Miejscowosc)";

                connection.Execute(insertQuery, customer);
            }

            return RedirectToAction("Index"); 
        }

        public class Customer1
        {
            public string Nazwa_Klienta { get; set; }
            public string Kraj { get; set; }
            public string Miejscowosc { get; set; }
        }

        [HttpPost]
        public IActionResult DodajProdukt(string nazwaProduktu, decimal cenaProduktu, int idZamowienia)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                string insertQuery = "INSERT INTO Products (nazwa_produktu, cena_produktu, ID_zamowienia) VALUES (@NazwaProduktu, @CenaProduktu, @IDZamowienia)";

                connection.Execute(insertQuery, new { NazwaProduktu = nazwaProduktu, CenaProduktu = cenaProduktu, IDZamowienia = idZamowienia });
            }

            return RedirectToAction("Index"); 
        }

        public IActionResult EdytujProdukt(int id)
        {
            using var connection = new MySqlConnection(connectionString);
            var product = connection.QuerySingleOrDefault<Product>(
                "SELECT ID_produktu, nazwa_produktu, cena_produktu, ID_zamowienia FROM Products WHERE ID_produktu = @ProductId;",
                new { ProductId = id }
            );

            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        [HttpPost]
        public IActionResult ZapiszEdycje(Product product)
        {
            if (ModelState.IsValid)
            {
                using var connection = new MySqlConnection(connectionString);
                string query = "UPDATE Products SET nazwa_produktu = @NazwaProduktu, cena_produktu = @CenaProduktu, ID_zamowienia = @IDZamowienia WHERE ID_produktu = @IDProduktu";
                connection.Execute(query, new { NazwaProduktu = product.nazwa_produktu, CenaProduktu = product.cena_produktu, IDZamowienia = product.ID_zamowienia, IDProduktu = product.ID_produktu });
                return RedirectToAction("Index");
            }
            return View("EdytujProdukt", product);
        }

        public IActionResult EdytujKlienta(int id)
        {
            using var connection = new MySqlConnection(connectionString);
            var customer = connection.QuerySingleOrDefault<Customer>(
                "SELECT ID_klienta, nazwa_klienta, Kraj, miejscowosc FROM Customers WHERE ID_klienta = @KlientId;",
                new { KlientId = id }
            );

            if (customer == null)
            {
                return NotFound();
            }

            return View("EdytujKlienta", customer);
        }

        [HttpPost]
        public IActionResult ZapiszEdycjeKlienta(Customer customer)
        {
            if (ModelState.IsValid)
            {
                using var connection = new MySqlConnection(connectionString);
                connection.Execute(
                    "UPDATE Customers SET nazwa_klienta = @NazwaKlienta, Kraj = @Kraj, miejscowosc = @Miejscowosc WHERE ID_klienta = @KlientId;",
                    new { NazwaKlienta = customer.nazwa_klienta, Kraj = customer.Kraj, Miejscowosc = customer.miejscowosc, KlientId = customer.ID_klienta }
                );

                return RedirectToAction("Index"); // Przekierowanie do widoku listy klientów
            }

            return View("EdytujKlienta", customer);
        }

        public IActionResult EdytujZamowienie(int id)
        {
            using var connection = new MySqlConnection(connectionString);
            var order = connection.QuerySingleOrDefault<Order>(
                "SELECT ID, Nr_zamowienia, ID_klienta, Data_zamowienia, Ilosc FROM Orders WHERE ID = @OrderId;",
                new { OrderId = id }
            );

            if (order == null)
            {
                return NotFound();
            }

            return View("EdytujZamowienie", order);
        }

        [HttpPost]
        public IActionResult ZapiszEdycjeZamowienia(Order order)
        {
            if (ModelState.IsValid)
            {
                using var connection = new MySqlConnection(connectionString);
                connection.Execute(
                    "UPDATE Orders SET Nr_zamowienia = @NumerZamowienia, ID_klienta = @IdKlienta, Data_zamowienia = @DataZamowienia, Ilosc = @Ilosc WHERE ID = @OrderId;",
                    new { NumerZamowienia = order.Nr_zamowienia, IdKlienta = order.ID_klienta, DataZamowienia = order.Data_zamowienia, Ilosc = order.Ilosc, OrderId = order.ID }
                );

                return RedirectToAction("Index"); // Przekierowanie do widoku listy zamówień
            }

            return View("EdytujZamowienie", order);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
