﻿namespace mvc1.Models
{
    public class Product
    {
        public int ID_produktu { get; set; }
        public string nazwa_produktu { get; set; }
        public decimal cena_produktu { get; set; }
        public int ID_zamowienia { get; set; }
    }
}
