﻿namespace mvc1.Models
{
    public class Customer  
    {
        public int ID_klienta { get; set; }
        public string Kraj { get; set; }
        public string miejscowosc { get; set; }
        public string nazwa_klienta { get; set; }
    }
}
