﻿namespace mvc1.Models
{
    public class OrderViewModel
    {
        public int ID { get; set; }
        public string Nr_zamowienia { get; set; }
        public int ID_klienta { get; set; }
        public DateTime Data_zamowienia { get; set; }
        public int Ilosc { get; set; }
    }
}
